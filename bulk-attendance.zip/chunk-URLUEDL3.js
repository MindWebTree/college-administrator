import"./chunk-NEB6MB4Y.js";var t=[{path:""}];export{t as default};
