import {
  MAT_BUTTON_CONFIG,
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
} from "./chunk-M6SEXPN6.js";
import "./chunk-YGBN4JTW.js";
import "./chunk-XLRJ3JNW.js";
import "./chunk-HN7ZVCGL.js";
import "./chunk-X2OMSDWJ.js";
import "./chunk-JL7AZPIE.js";
import "./chunk-M4MUQ4C7.js";
import "./chunk-MTLPE3W7.js";
import "./chunk-WSA2QMXP.js";
import "./chunk-X6JV76XL.js";
export {
  MAT_BUTTON_CONFIG,
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
};
//# sourceMappingURL=@angular_material_button.js.map
