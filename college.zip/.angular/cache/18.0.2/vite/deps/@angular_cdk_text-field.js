import {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
} from "./chunk-PEDEQYNY.js";
import "./chunk-X2OMSDWJ.js";
import "./chunk-JL7AZPIE.js";
import "./chunk-M4MUQ4C7.js";
import "./chunk-MTLPE3W7.js";
import "./chunk-WSA2QMXP.js";
import "./chunk-X6JV76XL.js";
export {
  AutofillMonitor,
  CdkAutofill,
  CdkTextareaAutosize,
  TextFieldModule
};
//# sourceMappingURL=@angular_cdk_text-field.js.map
