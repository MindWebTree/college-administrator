import {
  Platform,
  PlatformModule,
  RtlScrollAxisType,
  _getEventTarget,
  _getFocusedElementPierceShadowDom,
  _getShadowRoot,
  _isTestEnvironment,
  _supportsShadowDom,
  getRtlScrollAxisType,
  getSupportedInputTypes,
  normalizePassiveListenerOptions,
  supportsPassiveEventListeners,
  supportsScrollBehavior
} from "./chunk-JL7AZPIE.js";
import "./chunk-M4MUQ4C7.js";
import "./chunk-MTLPE3W7.js";
import "./chunk-WSA2QMXP.js";
import "./chunk-X6JV76XL.js";
export {
  Platform,
  PlatformModule,
  RtlScrollAxisType,
  _getEventTarget,
  _getFocusedElementPierceShadowDom,
  _getShadowRoot,
  _isTestEnvironment,
  _supportsShadowDom,
  getRtlScrollAxisType,
  getSupportedInputTypes,
  normalizePassiveListenerOptions,
  supportsPassiveEventListeners,
  supportsScrollBehavior
};
//# sourceMappingURL=@angular_cdk_platform.js.map
